#ifndef __FUNCIONALIDADES_H__
#define __FUNCIONALIDADES_H__

#include "topologiaRede.h"

void comando1(char*, char* );
void comando2(char*);
void comando3(char*);
void comando4(char*);
void comando5(char*);
void comando6(char*);

#endif
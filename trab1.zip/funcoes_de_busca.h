#ifndef __BUSCA_H__
#define __BUSCA_H__

#include "topologiaRede.h"

//compara inteiros
int compara_campo_inteiro(int, int, reg_dados*);

//compara strings
int compara_campo_string(int, char*, reg_dados* );

#endif
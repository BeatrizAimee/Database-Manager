#ifndef __CHECAGEM_H__
#define __CHECAGEM_H__

#include "topologiaRede.h"

int checa_consistencia(reg_cabecalho*);
int checa_remocao(reg_dados*);

#endif
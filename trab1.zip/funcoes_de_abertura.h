#ifndef __ABERTURA_H__
#define __ABERTURA_H__

#include "topologiaRede.h"

FILE* abrir_leitura(char*);
FILE* abrir_leitura_binario(char*);
FILE* abrir_escrita_binario(char*);
FILE* abrir_leitura_e_escrita_binario(char*);

#endif